**GMZ - Generator Morzeovih Znakova**   
proizvod tvrtke ETAS iz Splita u periodu 1983. do 1985.  
  
**Autori (izvorna dokumentacija el.sheme):**   
Konstruktor: Željko Ćosić dipl.ing.   
Razradio: Sveto Lušić  
Crtao: J. Ćuk  
Odobrio: Mladen Popović dipl. ing.  
**Sadržaj:**  
GMZ - UPUTSTVO ZA RUKOVANJE  
Program za obuku - LEKCIJE (1-26)  
GMZ modul ISPRAVLJAČ-MONITOR (el.shema)  
GMZ modul TASTATURA (el.shema)  
GMZ modul MEMORIJA (el.shema)  
GMZ modul AUTOMAT (el.shema)  
GMZ fotografija  
**Namjena:**  
GMZ je nastavnički uredjaj namjenjen za obuku radio-telegrafista.
